from __future__ import annotations

from dataclasses import dataclass

from .braille import encode_text_to_cells
from .graphics import GraphicsBuffer
from .utils import dots_to_byte
from .serial_driver import DotPad


@dataclass
class DotPadBuilder:
    """Build a graphics frame before sending it to the device."""

    buffer: GraphicsBuffer

    @classmethod
    def empty(cls) -> "DotPadBuilder":
        """Create a new empty builder."""
        return cls(GraphicsBuffer.empty())

    def clear(self) -> None:
        """Reset the buffer to all zeros."""
        self.buffer = GraphicsBuffer.empty()

    def set_cell(self, row: int, col: int, cell_byte: int) -> None:
        """Set a cell by 1-based cell coordinates.

        Args:
            row: Cell row (1..10).
            col: Cell column (1..30).
            cell_byte: 8-dot cell byte.
        """
        if not (1 <= row <= 10 and 1 <= col <= 30):
            return
        idx = (row - 1) * 30 + (col - 1)
        self.buffer.cells[idx] = cell_byte

    def draw_line(self, row: int, col: int, length: int) -> None:
        """Draw a horizontal line in dot coordinates."""
        for c in range(col, col + length):
            self.buffer.set_dot(row, c, True)

    def draw_vline(self, row: int, col: int, length: int) -> None:
        """Draw a vertical line in dot coordinates."""
        for r in range(row, row + length):
            self.buffer.set_dot(r, col, True)

    def draw_diag_line(self, row: int, col: int, length: int, direction: str = "ltr") -> None:
        """Draw a diagonal line in dot coordinates.

        Args:
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            length: Number of dots.
            direction: "ltr" (down-right) or "rtl" (down-left).
        """
        dc = 1 if direction == "ltr" else -1
        for i in range(length):
            self.buffer.set_dot(row + i, col + i * dc, True)

    def draw_rectangle(self, row1: int, col1: int, row2: int, col2: int) -> None:
        """Draw a rectangle using top-left and bottom-right dot coordinates."""
        top = min(row1, row2)
        bottom = max(row1, row2)
        left = min(col1, col2)
        right = max(col1, col2)
        self.draw_line(top, left, right - left + 1)
        self.draw_line(bottom, left, right - left + 1)
        self.draw_vline(top, left, bottom - top + 1)
        self.draw_vline(top, right, bottom - top + 1)

    def render_text(
        self,
        text: str,
        row: int,
        col: int,
        use_number_sign: bool = True,
        use_nemeth: bool = False,
    ) -> None:
        """Render braille text at dot coordinates.

        Args:
            text: Text to render.
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            use_number_sign: If True, inserts number sign before digit runs.
            use_nemeth: If True, use lowered 6-dot (Nemeth-style) digit cells.
        """
        cells = encode_text_to_cells(
            text,
            use_number_sign=use_number_sign,
            use_nemeth=use_nemeth,
        )
        self.buffer.draw_braille_text(cells, start_row=row, start_col=col)

    def render_text_dots(self, dots: str | list[str], row: int, col: int) -> None:
        """Render dot-pattern cells at dot coordinates.

        Args:
            dots: Dot patterns (e.g., "3456 1 12" or ["3456", "1", "12"]).
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
        """
        from .utils import dots_to_cells
        cells = dots_to_cells(dots)
        self.buffer.draw_braille_text(cells, start_row=row, start_col=col)

    def render_text_bytes(self, cells: bytes, row: int, col: int) -> None:
        """Render raw braille cell bytes at dot coordinates."""
        self.buffer.draw_braille_text(list(cells), start_row=row, start_col=col)

    def rows(self) -> list[bytes]:
        """Return the buffer as 10 rows of 30 cell bytes."""
        return self.buffer.to_rows()

    def send(self, dp: DotPad, send_all: bool = False) -> None:
        """Send the buffer to the device.

        Args:
            dp: Active DotPad device instance.
            send_all: If True, send all 10 graphics rows (including empty rows).
                If False, send only rows containing dots.
        """
        for i, row_bytes in enumerate(self.rows(), start=1):
            if send_all or any(b != 0 for b in row_bytes):
                dp.send_display_line(i, row_bytes)
