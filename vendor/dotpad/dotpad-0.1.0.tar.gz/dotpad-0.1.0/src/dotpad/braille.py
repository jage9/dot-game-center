"""Braille encoding helpers for DotPad."""

from __future__ import annotations

from .utils import dots_to_byte

# Basic uncontracted English (Grade 1) braille patterns.
# Dots are numbered 1-8, mapped to bytes via dots_to_byte.
_LETTER_DOTS = {
    "a": "1",
    "b": "12",
    "c": "14",
    "d": "145",
    "e": "15",
    "f": "124",
    "g": "1245",
    "h": "125",
    "i": "24",
    "j": "245",
    "k": "13",
    "l": "123",
    "m": "134",
    "n": "1345",
    "o": "135",
    "p": "1234",
    "q": "12345",
    "r": "1235",
    "s": "234",
    "t": "2345",
    "u": "136",
    "v": "1236",
    "w": "2456",
    "x": "1346",
    "y": "13456",
    "z": "1356",
}

# Common punctuation (Grade 1). Extend as needed.
_PUNCT_DOTS = {
    ",": "2",
    ";": "23",
    ":": "25",
    ".": "256",
    "!": "235",
    "?": "236",
    "'": "3",
    "\"": "356",
    "-": "36",
    "(": "236",
    ")": "356",
    "/": "34",
    "@": "4",
}

_DIGIT_TO_LETTER = {
    "1": "a",
    "2": "b",
    "3": "c",
    "4": "d",
    "5": "e",
    "6": "f",
    "7": "g",
    "8": "h",
    "9": "i",
    "0": "j",
}

# Lowered 6-dot digits (standard Nemeth-style numeric set).
_DIGIT_DOTS_NEMETH = {
    "1": "2",
    "2": "23",
    "3": "25",
    "4": "256",
    "5": "26",
    "6": "235",
    "7": "2356",
    "8": "236",
    "9": "35",
    "0": "356",
}


def encode_text_to_cells(
    text: str,
    use_number_sign: bool = True,
    use_nemeth: bool = False,
) -> list[int]:
    """Encode text into 8-dot braille cell bytes.

    Args:
        text: Input string to encode.
        use_number_sign: If True, insert the number sign before digit runs.
        use_nemeth: If True, use lowered (Nemeth-style) digit cells.

    Returns:
        List of 8-dot braille cell bytes.
    """
    cells: list[int] = []
    in_number = False
    for ch in text:
        if ch.isdigit():
            if use_number_sign and not in_number:
                cells.append(dots_to_byte("3456"))
            in_number = True
            if use_nemeth:
                cells.append(dots_to_byte(_DIGIT_DOTS_NEMETH[ch]))
            else:
                letter = _DIGIT_TO_LETTER[ch]
                cells.append(dots_to_byte(_LETTER_DOTS[letter]))
            continue
        in_number = False
        if ch == " ":
            cells.append(0x00)
            continue
        lower = ch.lower()
        if lower in _LETTER_DOTS:
            cells.append(dots_to_byte(_LETTER_DOTS[lower]))
            continue
        if ch in _PUNCT_DOTS:
            cells.append(dots_to_byte(_PUNCT_DOTS[ch]))
            continue
        # Unknown -> blank
        cells.append(0x00)
    return cells
