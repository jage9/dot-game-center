import argparse
import sys

from serial.tools import list_ports

import dotpad as dp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", help="COM port, e.g., COM5 (auto-detect if omitted)")
    parser.add_argument("--dots", default="14", help="Dots for graphic byte (1-8), e.g., 14")
    parser.add_argument("--line", type=int, default=None, help="1-based line number to write")
    parser.add_argument("--page", action="store_true", help="Write full page line-by-line")
    parser.add_argument("--clear", action="store_true", help="Clear graphics and text before writing")
    parser.add_argument("--clear-graphics", action="store_true", help="Clear graphics area only")
    parser.add_argument("--clear-text", action="store_true", help="Clear text line only")
    parser.add_argument("--text", default=None, help="Encode text to braille and send to text line")
    parser.add_argument("--graphics-text", default=None, help="Render braille text into graphics area")
    parser.add_argument("--graphics-clear", action="store_true", help="Clear graphics before graphics-text")
    parser.add_argument("--row", type=int, default=1, help="Start row (1-40) for graphics text")
    parser.add_argument("--col", type=int, default=1, help="Start col (1-60) for graphics text")
    if len(sys.argv) == 1:
        parser.print_help()
        raise SystemExit(1)
    args = parser.parse_args()

    # Auto-detect FTDI DotPad if --port isn't provided.
    port = args.port
    if not port:
        for p in list_ports.comports():
            if p.vid == 0x0403 and p.pid == 0x6010:
                port = p.device
                break
    if not port:
        raise SystemExit("No COM port specified or detected. Use --port COMx.")
    print(f"Using DotPad port: {port}")

    cell_value = dp.dots_to_byte(args.dots)
    # Open the device and run the requested actions.
    pad = dp.DotPad(port)
    try:
        if args.clear or args.clear_graphics:
            pad.fill_rows(cells_per_row=30, rows=10, cell_value=0x00)
        if args.clear or args.clear_text:
            pad.send_text_bytes(bytes([0x00]) * 20)
        if args.line is not None:
            row = bytes([cell_value]) * 30
            ok = pad.send_display_line(args.line, row)
            print(f"line {args.line} ack:", ok)
        if args.page:
            pad.fill_rows(cells_per_row=30, rows=10, cell_value=cell_value)
            print("page done")
        if args.text:
            cells = bytes(dp.encode_text_to_cells(args.text))
            ok = pad.send_text_bytes(cells)
            print("text line ack:", ok)
        if args.graphics_text:
            buf = dp.GraphicsBuffer.empty()
            cells = dp.encode_text_to_cells(args.graphics_text)
            buf.draw_braille_text(cells, start_row=args.row, start_col=args.col)
            rows = buf.to_rows()
            if args.graphics_clear:
                for i, row_bytes in enumerate(rows, start=1):
                    pad.send_display_line(i, row_bytes)
            else:
                for i, row_bytes in enumerate(rows, start=1):
                    if any(b != 0 for b in row_bytes):
                        pad.send_display_line(i, row_bytes)
    except KeyboardInterrupt:
        pass
    finally:
        pad.close()


if __name__ == "__main__":
    main()
