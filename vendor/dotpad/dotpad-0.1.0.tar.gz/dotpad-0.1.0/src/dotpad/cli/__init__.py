"""Console tools for the DotPad package."""
