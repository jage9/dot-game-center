"""Shared constants and helpers."""

GRAPHIC_DOT_BITS = {
    1: 0x01,
    2: 0x02,
    3: 0x04,
    4: 0x10,
    5: 0x20,
    6: 0x40,
    7: 0x08,
    8: 0x80,
}


def dots_to_byte(dots: str) -> int:
    """Convert dot numbers into a single 8-dot cell byte.

    Args:
        dots: String of dot numbers, e.g. "145".

    Returns:
        Cell byte with those dots set.
    """
    value = 0
    for ch in dots:
        if ch.isdigit():
            dot = int(ch)
            value |= GRAPHIC_DOT_BITS.get(dot, 0)
    return value


def dots_to_cells(dots: str | list[str]) -> list[int]:
    """Convert dot patterns into a list of cell bytes.

    Args:
        dots: Either a single dot string (e.g. "3456"), a space/comma-separated
            string of dot patterns (e.g. "1 145 24" or "1,145,24"), or a list
            of strings.

    Returns:
        List of cell bytes.
    """
    if isinstance(dots, list):
        parts = dots
    else:
        normalized = dots.replace(",", " ").strip()
        parts = normalized.split()
        if not parts:
            parts = [dots]
    return [dots_to_byte(part) for part in parts]
