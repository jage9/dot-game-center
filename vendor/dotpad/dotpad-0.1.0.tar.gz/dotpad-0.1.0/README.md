# DotPad Python (Serial)

A small, reliable serial wrapper for DotPad. It writes graphics line‑by‑line (stable for full‑page output) and supports the 20‑cell text line.

## Install (wheel, recommended)
Build the wheel from this repo (run from repo root):
```
uv sync --project python
./python/build_wheel.ps1
```

Then install it in your new project environment:
```
uv pip install python/dist/dotpad-0.1.0-py3-none-any.whl
```

Command notes:
- `uv sync --project python` installs runtime deps declared in `python/pyproject.toml`.
- `build_wheel.ps1` builds a wheel into `python/dist/` using `uv build`.
- `uv pip install ...whl` installs the wheel into your active environment.

## Quick start
```python
import dotpad as dp

pad = dp.DotPad()
pad.clear_all()
pad.send_text("HELLO, WORLD!")
pad.send_graphics("THIS WORKS!", row=1, col=1)
pad.close()
```

## Examples (in this repo)
Run from `python/`:
```
cd python
uv run python examples/hello_world.py
```

Command note:
- `uv run python ...` runs the example using the current `uv` environment.

Other examples:
- `examples/cal.py` — current month calendar (graphics).
- `examples/cal_int.py` — interactive calendar (panLeft/panRight, f1/f4, f2).
- `examples/grid.py` — horizontal + vertical grid.
- `examples/word_list.py` — words + numeric values on the right.
- `examples/keys.py` — key presses (panLeft/panRight/f1–f4).
- `examples/keys_chord.py` — chorded key presses on release. (experimental)
- `examples/dtm_info.py` — DTM file inspector + optional display.
- `examples/dotpad_serial_test.py` — low‑level test CLI.

## Public API (core)
All of these are available from `import dotpad as dp`.

### Device
- `dp.DotPad(port: str | None = None, timeout: float = 0.2)`
  - Opens the serial connection; auto‑detects the FTDI DotPad USB port if `port` is None.
  - Example: `pad = dp.DotPad()` or `pad = dp.DotPad(port="COM5")`

### Text line
- `send_text(text: str, use_number_sign: bool = True, use_nemeth: bool = False)`
  - Encode text and send it to the 20‑cell text line.
  - Example: `pad.send_text("HELLO")`
  - Example (Nemeth digits, no number sign): `pad.send_text("F1", use_number_sign=False, use_nemeth=True)`
- `send_text_dots(dots: str | list[str])`
  - Send braille cell dots to the text line (max 20 cells).
  - Example: `pad.send_text_dots("3456 1 12")` (space/comma separated)
- `send_text_bytes(cells: bytes)`
  - Send raw braille cell bytes to the text line (max 20 cells).
  - Example: `pad.send_text_bytes(b"\x01\x03\x00")`
- `clear_text()`
  - Clear the text line (20 zero cells).
  - Example: `pad.clear_text()`

### Graphics
- `clear_graphics()`
  - Clear the entire graphics area.
  - Example: `pad.clear_graphics()`
- `clear_all()`
  - Clear both graphics and text areas.
  - Example: `pad.clear_all()`
- `send_graphics(text: str, row: int, col: int, use_number_sign: bool = True, use_nemeth: bool = False)`  # dot coords
  - Render braille text at dot coordinates (row 1..40, col 1..60).
  - Example: `pad.send_graphics("OK", row=1, col=1)`
  - Example (Nemeth digits): `pad.send_graphics("123", row=1, col=1, use_nemeth=True)`
- `send_graphics_dots(dots: str | list[str], row: int, col: int)`  # dot coords
  - Render braille cell dots at dot coordinates.
  - Example: `pad.send_graphics_dots("145,24", row=1, col=1)`
- `send_graphics_bytes(cells: bytes, row: int, col: int)`  # dot coords
  - Render raw braille cell bytes at dot coordinates.
  - Example: `pad.send_graphics_bytes(b"\x01\x03", row=1, col=1)`
- `draw_line(row: int, col: int, length: int)`  # dot coords
  - Draw a horizontal dot line.
  - Example: `pad.draw_line(row=1, col=1, length=20)`
- `draw_vline(row: int, col: int, length: int)`
  - Draw a vertical dot line.
  - Example: `pad.draw_vline(row=1, col=1, length=20)`
- `draw_diag_line(row: int, col: int, length: int, direction: str = "ltr")`
  - Draw a diagonal dot line (direction: `ltr` = down‑right, `rtl` = down‑left).
  - Example: `pad.draw_diag_line(row=1, col=1, length=10, direction=\"rtl\")`
- `draw_rectangle(row1: int, col1: int, row2: int, col2: int)`
  - Draw a rectangle using dot coordinates.
  - Example: `pad.draw_rectangle(1, 1, 10, 20)`

### Builder (buffered graphics)
Use the builder when you want to compose a full frame in memory, then send only
the rows that contain dots (efficient for partial updates).

- `pad.builder()`
  - Create a new empty builder attached to the device.
  - Example: `builder = pad.builder()`
- `dp.DotPadBuilder.empty()`
  - Create a new empty graphics buffer.
  - Example: `builder = dp.DotPadBuilder.empty()`
- `set_cell(row: int, col: int, cell_byte: int)`  # cell coords
  - Set a single 8‑dot cell by cell coordinates (1..10, 1..30).
  - Example: `builder.set_cell(1, 1, 0x11)`
- `draw_line(row: int, col: int, length: int)`  # dot coords
  - Draw a horizontal dot line into the buffer.
  - Example: `builder.draw_line(1, 1, 20)`
- `draw_vline(row: int, col: int, length: int)`  # dot coords
  - Draw a vertical dot line into the buffer.
  - Example: `builder.draw_vline(1, 1, 20)`
- `draw_diag_line(row: int, col: int, length: int, direction: str = "ltr")`  # dot coords
  - Draw a diagonal dot line into the buffer.
  - Example: `builder.draw_diag_line(1, 1, 10, direction=\"ltr\")`
- `draw_rectangle(row1: int, col1: int, row2: int, col2: int)`  # dot coords
  - Draw a rectangle into the buffer.
  - Example: `builder.draw_rectangle(1, 1, 10, 20)`
- `render_text(text, row, col, use_number_sign=True, use_nemeth=False)`  # dot coords
  - Render braille text into the buffer.
  - Example: `builder.render_text(\"OK\", 1, 1)`
- `render_text_dots(dots, row, col)`  # dot coords
  - Render braille dot patterns into the buffer.
  - Example: `builder.render_text_dots(\"145 24\", 1, 1)`
- `render_text_bytes(cells, row, col)`  # dot coords
  - Render raw braille cell bytes into the buffer.
  - Example: `builder.render_text_bytes(b\"\\x01\\x03\", 1, 1)`
- `send(pad)`  # sends only rows with dots
  - Send only non‑empty rows to the device.
  - Example: `builder.send(pad)`

### Helpers
- `dp.encode_text_to_cells(text, use_number_sign=True, use_nemeth=False)`
  - Convert text into braille cell bytes.
  - Example: `cells = dp.encode_text_to_cells(\"ABC\")`
- `dp.dots_to_cells(\"145 24\")`
  - Convert braille dot patterns into a list of cell bytes.
  - Example: `cells = dp.dots_to_cells(\"3456 1 12\")`

### Low-level helpers (protocol-oriented)
- `send_display_line(destination: int, cells: bytes)`  # lines 1..10
  - Send a single 30‑cell graphics row to line 1..10.
  - Example: `pad.send_display_line(1, bytes([0x11]) * 30)`
- `fill_rows(cells_per_row: int, rows: int, cell_value: int)`
  - Fill multiple rows with a repeated cell byte.
  - Example: `pad.fill_rows(30, 10, 0x00)`
- `fill_graphics(cell_byte: int)`
  - Fill the entire 30x10 graphics area with a repeated cell byte.
  - Example: `pad.fill_graphics(0x00)`
- `dp.dots_to_byte("145")`
  - Convert braille dot numbers into a single cell byte.
  - Example: `b = dp.dots_to_byte("3456")`

## Command-line tools (after install)
These are provided via console scripts:
```
dotpad-test --clear --page --dots 14
dotpad-dtm-info path/to/file.dtm --send
```

## dotpad-test
Usage:
```
dotpad-test [options]
```

Options:
- `--port`: COM port, e.g., `COM5` (auto‑detects if omitted).
- `--dots`: Graphics dots to set (1‑8), e.g., `14` for dots 1+4.
- `--line`: 1‑based line number to write (1..10).
- `--page`: Sends a full page (10 lines).
- `--clear`: Clears graphics and text first.
- `--clear-graphics`: Clears graphics only.
- `--clear-text`: Clears text only.
- `--text-hex`: Send raw braille cell bytes to the text line (hex string).
- `--text`: Encode text to braille and send to text line.
- `--graphics-text`: Render braille text into graphics area.
- `--graphics-clear`: Clear graphics before graphics text (default is overlay).
- `--row`: Start row (1..40) for graphics text.
- `--col`: Start col (1..60) for graphics text.

Example:
```
dotpad-test --clear --page --dots 14
```

## dotpad-dtm-info
Usage:
```
dotpad-dtm-info <path> [options]
```

Options:
- `--send`: Display the DTM on the device.
- `--port`: COM port, e.g., `COM5` (auto‑detects if omitted).
- `--cols`: Columns for display (default 30).
- `--rows`: Rows for display (default 10).
- `--use-header`: Use header width/height for cols/rows.

Example:
```
dotpad-dtm-info path\\to\\file.dtm --send --use-header
```

## Notes
- Line numbers are 1‑based (line 1 is the top row).
- The text line is **20 cells**; sending more can wrap into graphics.

### Dot mapping (graphics + text)
Both areas use the same 8‑dot mapping:
- dot 1 → 0x01
- dot 2 → 0x02
- dot 3 → 0x04
- dot 4 → 0x10
- dot 5 → 0x20
- dot 6 → 0x40
- dot 7 → 0x08
- dot 8 → 0x80

So dots `1+4` is `0x11`, dots `1+2+3` is `0x07`, etc.

### Number options
Digits support two independent flags:
- `use_number_sign` (default `True`)
  - Adds dot `3456` before digit runs.
- `use_nemeth` (default `False`)
  - Uses lowered 6-dot (standard Nemeth-style) digit cells.

Common combinations:
- `use_number_sign=True, use_nemeth=False` (default)
- `use_number_sign=False, use_nemeth=False`
- `use_number_sign=True, use_nemeth=True`
- `use_number_sign=False, use_nemeth=True`
