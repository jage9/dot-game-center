"""Public package exports for the DotPad wrapper."""

from .serial_driver import DotPad
from .utils import dots_to_byte, dots_to_cells
from .braille import encode_text_to_cells
from .graphics import GraphicsBuffer
from .builder import DotPadBuilder

__all__ = [
    "DotPad",
    "dots_to_byte",
    "dots_to_cells",
    "encode_text_to_cells",
    "GraphicsBuffer",
    "DotPadBuilder",
]

__version__ = "0.1.0"
