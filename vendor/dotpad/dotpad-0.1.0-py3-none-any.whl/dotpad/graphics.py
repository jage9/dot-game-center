"""Graphics buffer utilities for 60x40 dot grids."""

from __future__ import annotations

from dataclasses import dataclass

from .utils import GRAPHIC_DOT_BITS

DOT_COLS = 60
DOT_ROWS = 40
CELL_COLS = 30
CELL_ROWS = 10
CELL_WIDTH = 2
CELL_HEIGHT = 4

DOT_OFFSETS = {
    1: (0, 0),
    2: (1, 0),
    3: (2, 0),
    7: (3, 0),
    4: (0, 1),
    5: (1, 1),
    6: (2, 1),
    8: (3, 1),
}


def _dot_number(col_in_cell: int, row_in_cell: int) -> int:
    """Map a dot position inside a cell to its 1-8 dot number."""
    if col_in_cell == 0:
        return row_in_cell + 1 if row_in_cell < 3 else 7
    return row_in_cell + 4 if row_in_cell < 3 else 8


def _normalize_text_direction(direction: str) -> str:
    normalized = str(direction or "right").lower()
    if normalized in {"left", "up", "down"}:
        return normalized
    return "right"


def _rotate_dot_offset(row_offset: int, col_offset: int, direction: str) -> tuple[int, int]:
    """Rotate a dot offset around dot-1 anchor based on text direction."""
    if direction == "left":
        return -row_offset, -col_offset
    if direction == "down":
        return col_offset, -row_offset
    if direction == "up":
        return -col_offset, row_offset
    return row_offset, col_offset


@dataclass
class GraphicsBuffer:
    """60x40 dot grid backed by 30x10 cell bytes."""

    cells: list[int]

    @classmethod
    def empty(cls) -> "GraphicsBuffer":
        """Create an empty graphics buffer (all dots off)."""
        return cls([0] * (CELL_COLS * CELL_ROWS))

    def _cell_index(self, cell_col: int, cell_row: int) -> int:
        """Compute the flat index into the cell array."""
        return cell_row * CELL_COLS + cell_col

    def set_dot(self, row: int, col: int, on: bool = True) -> None:
        """Set or clear a dot by 1-based dot coordinates.

        Args:
            row: Dot row (1..40).
            col: Dot column (1..60).
            on: True to set, False to clear.
        """
        if not (1 <= row <= DOT_ROWS and 1 <= col <= DOT_COLS):
            return
        cell_col = (col - 1) // CELL_WIDTH
        cell_row = (row - 1) // CELL_HEIGHT
        col_in = (col - 1) % CELL_WIDTH
        row_in = (row - 1) % CELL_HEIGHT
        dot_no = _dot_number(col_in, row_in)
        bit = GRAPHIC_DOT_BITS[dot_no]
        idx = self._cell_index(cell_col, cell_row)
        if on:
            self.cells[idx] |= bit
        else:
            self.cells[idx] &= ~bit

    def draw_braille_text(
        self,
        text_cells: list[int],
        start_row: int,
        start_col: int,
        direction: str = "right",
    ) -> None:
        """Render braille cells into the dot grid with directional rotation.

        Args:
            text_cells: Sequence of braille cell bytes.
            start_row: Starting dot row (1-based).
            start_col: Starting dot column (1-based).
            direction: Text flow direction: right (default), left, up, or down.
                For non-right directions, cell dots are rotated while keeping
                dot-1 of each cell anchored on the current row/col cursor.
        """
        direction = _normalize_text_direction(direction)
        row = start_row
        col = start_col
        for cell in text_cells:
            for dot_no, bit in GRAPHIC_DOT_BITS.items():
                if cell & bit:
                    r_off, c_off = DOT_OFFSETS[dot_no]
                    rr, cc = _rotate_dot_offset(r_off, c_off, direction)
                    self.set_dot(row + rr, col + cc, True)
            if direction == "left":
                col -= 3
            elif direction == "up":
                row -= 3
            elif direction == "down":
                row += 3
            else:
                col += 3  # 2 dots for cell + 1 dot gap

    def to_rows(self) -> list[bytes]:
        """Return the graphics buffer as 10 rows of 30 cell bytes."""
        rows: list[bytes] = []
        for row in range(CELL_ROWS):
            start = row * CELL_COLS
            rows.append(bytes(self.cells[start : start + CELL_COLS]))
        return rows
