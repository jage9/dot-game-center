"""Serial protocol implementation for DotPad devices."""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import logging
import serial
from serial.tools import list_ports

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

DP_SYNC = b"\xaa\x55"
SERIAL_BAUD_RATE = 115200

class PacketType(Enum):
    """Packet type identifiers used by the DotPad protocol."""
    REQ_DISPLAY_LINE = b"\x02\x00"
    RSP_DISPLAY_LINE = b"\x02\x01"
    NTF_DISPLAY_LINE = b"\x02\x02"
    NTF_KEYS_SCROLL = b"\x03\x02"
    NTF_KEYS_PERKINS = b"\x03\x12"
    NTF_KEYS_ROUTING = b"\x03\x22"
    NTF_KEYS_FUNCTION = b"\x03\x32"

class ResponseCode(Enum):
    """Response codes returned by the device."""
    ACK = 0
    NAK = 1
    WAIT = 2
    CHECKSUM = 3

    @classmethod
    def from_code(cls, code: int) -> "ResponseCode":
        """Map a numeric response code to a ResponseCode enum.

        Args:
            code: Raw response code from the device.

        Returns:
            Matching ResponseCode; defaults to NAK if unknown.
        """
        for item in cls:
            if item.value == code:
                return item
        return ResponseCode.NAK


class KeyGroup(Enum):
    """Key notification group identifiers."""
    SCROLL = PacketType.NTF_KEYS_SCROLL.value[1]
    PERKINS = PacketType.NTF_KEYS_PERKINS.value[1]
    ROUTING = PacketType.NTF_KEYS_ROUTING.value[1]
    FUNCTION = PacketType.NTF_KEYS_FUNCTION.value[1]

@dataclass
class Packet:
    """Parsed protocol packet container."""
    raw: bytes
    length: int
    destination: int
    packet_type: Optional[PacketType]
    seq: int
    args: bytes
    checksum: int

    @staticmethod
    def calculate_checksum(data: bytes) -> int:
        """Compute the XOR checksum for a packet payload."""
        checksum = 0xA5
        for b in data:
            checksum ^= b
        return checksum

    @classmethod
    def make_packet(
        cls,
        packet_type: PacketType,
        args: bytes = b"",
        destination: int = 0,
        seq: int = 0,
    ) -> bytes:
        """Create a raw packet for transmission.

        Args:
            packet_type: Packet type enum.
            args: Payload bytes.
            destination: Destination line (0..10).
            seq: Sequence number.

        Returns:
            Raw packet bytes including sync and checksum.
        """
        destination_b = destination.to_bytes(1, "big")
        seq_b = seq.to_bytes(1, "big")
        length = len(destination_b + packet_type.value + seq_b + args) + 1
        length_b = length.to_bytes(2, "big")
        checksum = cls.calculate_checksum(destination_b + packet_type.value + seq_b + args)
        checksum_b = checksum.to_bytes(1, "big")
        return DP_SYNC + length_b + destination_b + packet_type.value + seq_b + args + checksum_b

    @classmethod
    def parse(cls, raw: bytes) -> "Packet":
        """Parse raw packet bytes into a Packet object."""
        length = int.from_bytes(raw[2:4], "big")
        destination = raw[4]
        packet_type = None
        try:
            packet_type = PacketType(raw[5:7])
        except ValueError:
            packet_type = None
        seq = raw[7]
        args = raw[8:-1]
        checksum = raw[-1]
        return cls(raw=raw, length=length, destination=destination, packet_type=packet_type, seq=seq, args=args, checksum=checksum)

class DotPad:
    """Serial DotPad driver for line-by-line graphics and text."""
    def __init__(self, port: str | None = None, timeout: float = 0.2) -> None:
        """Create a DotPad instance.

        Args:
            port: COM port name (e.g., "COM5"). Auto-detect if None.
            timeout: Serial read timeout in seconds.
        """
        if port is None:
            port = self.detect_port()
        if not port:
            raise RuntimeError("No DotPad USB port detected")
        self.port = port
        self._ser = serial.Serial(port, SERIAL_BAUD_RATE, timeout=timeout)

    @classmethod
    def detect_port(cls) -> str | None:
        """Detect the first FTDI DotPad port.

        Returns:
            COM port string or None if not found.
        """
        for p in list_ports.comports():
            if p.vid == 0x0403 and p.pid == 0x6010:
                return p.device
        return None

    def builder(self):
        """Create a new DotPadBuilder for buffered graphics."""
        from .builder import DotPadBuilder
        return DotPadBuilder.empty()



    def close(self) -> None:
        """Close the underlying serial port."""
        if self._ser.is_open:
            self._ser.close()

    def _read_exact(self, n: int) -> bytes:
        """Read exactly n bytes from the serial port (best-effort)."""
        data = b""
        while len(data) < n:
            chunk = self._ser.read(n - len(data))
            if not chunk:
                break
            data += chunk
        return data

    def read_packet(self, timeout: float = 0.5) -> Optional[Packet]:
        """Read a single packet from the device, if available."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            b = self._ser.read(1)
            if not b:
                continue
            if b != DP_SYNC[:1]:
                continue
            b2 = self._ser.read(1)
            if b2 != DP_SYNC[1:2]:
                continue
            length_b = self._read_exact(2)
            if len(length_b) < 2:
                continue
            length = int.from_bytes(length_b, "big")
            payload = self._read_exact(length)
            if len(payload) < length:
                continue
            raw = DP_SYNC + length_b + payload
            return Packet.parse(raw)
        return None

    @staticmethod
    def _decode_keys(args: bytes) -> list[int]:
        """Decode packed key bits into a list of key indices."""
        keys_pressed_bitstring = b""
        for byte in args:
            bit_string = format(byte, "08b").encode()
            reversed_bit_string = bit_string[::-1]
            keys_pressed_bitstring = reversed_bit_string + keys_pressed_bitstring
        keys_pressed = int(keys_pressed_bitstring, 2) if keys_pressed_bitstring else 0
        pressed = []
        for i in range(len(args) * 8):
            if (keys_pressed >> i) & 1:
                pressed.append(i)
        return pressed

    @staticmethod
    def _map_key_names(group_num: int, keys: list[int]) -> list[str]:
        """Map key indices to friendly names for known groups."""
        names: list[str] = []
        if group_num == KeyGroup.FUNCTION.value:
            for key in keys:
                names.append(f"f{key + 1}")
        elif group_num == KeyGroup.PERKINS.value:
            for key in keys:
                if key == 13:
                    names.append("panLeft")
                elif key == 14:
                    names.append("panRight")
        return names

    def listen_keys(self, callback, timeout: float = 0.5) -> None:
        """Listen for key notifications and call callback(names).

        Args:
            callback: Function called with a list of key names.
            timeout: Read timeout used while listening.
        """
        while True:
            pkt = self.read_packet(timeout=timeout)
            if not pkt or pkt.packet_type is None:
                continue
            if pkt.packet_type in (
                PacketType.NTF_KEYS_SCROLL,
                PacketType.NTF_KEYS_PERKINS,
                PacketType.NTF_KEYS_ROUTING,
                PacketType.NTF_KEYS_FUNCTION,
            ):
                group_num = pkt.packet_type.value[1]
                keys = self._decode_keys(pkt.args)
                if not keys:
                    continue
                names = self._map_key_names(group_num, keys)
                try:
                    callback(names)
                except Exception:
                    logger.exception("Key callback raised an exception")

    def listen_chords(self, callback, timeout: float = 0.5, debounce: float = 0.05) -> None:
        """Listen for chorded keys and call callback(names) on release.

        Args:
            callback: Function called with the chord key list.
            timeout: Read timeout used while listening.
            debounce: Window to collect late packets on release.
        """
        current_groups: dict[int, set[int]] = {}
        last_names: list[str] = []
        while True:
            pkt = self.read_packet(timeout=timeout)
            if not pkt or pkt.packet_type is None:
                continue
            if pkt.packet_type not in (
                PacketType.NTF_KEYS_SCROLL,
                PacketType.NTF_KEYS_PERKINS,
                PacketType.NTF_KEYS_ROUTING,
                PacketType.NTF_KEYS_FUNCTION,
            ):
                continue
            group_num = pkt.packet_type.value[1]
            keys = self._decode_keys(pkt.args)
            if keys:
                current_groups[group_num] = set(keys)
                # update last_names from all groups
                names: list[str] = []
                for grp, grp_keys in current_groups.items():
                    names.extend(self._map_key_names(grp, sorted(grp_keys)))
                last_names = names
                continue
            # Release event
            if group_num in current_groups:
                current_groups.pop(group_num)
            if not current_groups and last_names:
                # Debounce window to catch late key packets
                deadline = time.time() + debounce
                while time.time() < deadline:
                    pkt2 = self.read_packet(timeout=0.01)
                    if not pkt2 or pkt2.packet_type is None:
                        continue
                    if pkt2.packet_type not in (
                        PacketType.NTF_KEYS_SCROLL,
                        PacketType.NTF_KEYS_PERKINS,
                        PacketType.NTF_KEYS_ROUTING,
                        PacketType.NTF_KEYS_FUNCTION,
                    ):
                        continue
                    grp2 = pkt2.packet_type.value[1]
                    keys2 = self._decode_keys(pkt2.args)
                    if keys2:
                        current_groups[grp2] = set(keys2)
                        names: list[str] = []
                        for grp, grp_keys in current_groups.items():
                            names.extend(self._map_key_names(grp, sorted(grp_keys)))
                        last_names = names
                        break
                if not current_groups:
                    try:
                        callback(last_names)
                    except Exception:
                        logger.exception("Chord callback raised an exception")
                    last_names = []

    def send_display_line(self, destination: int, cells: bytes) -> bool:
        """Send a single row to a destination line.

        Args:
            destination: 1..10 for graphics, 0 for text line.
            cells: Row bytes (30 for graphics, up to 20 for text).

        Returns:
            True if ACK received, False otherwise.
        """
        args = bytes([0]) + cells
        packet = Packet.make_packet(PacketType.REQ_DISPLAY_LINE, args=args, destination=destination, seq=0)
        self._ser.write(packet)
        pkt = self.read_packet(timeout=0.5)
        if not pkt or pkt.packet_type is None:
            return False
        if pkt.packet_type == PacketType.NTF_DISPLAY_LINE:
            return True
        if pkt.packet_type == PacketType.RSP_DISPLAY_LINE and pkt.args:
            code = ResponseCode.from_code(pkt.args[0])
            return code == ResponseCode.ACK
        return False

    def send_text_dots(self, dots: str | list[str]) -> bool:
        """Send dot-pattern cells to the text line.

        Args:
            dots: Dot patterns (e.g., "3456 1 12" or ["3456", "1", "12"]).

        Returns:
            True if ACK received, False otherwise.
        """
        from .utils import dots_to_cells
        cells = bytes(dots_to_cells(dots))
        return self.send_display_line(destination=0, cells=cells)

    def send_text_bytes(self, cells: bytes) -> bool:
        """Send raw braille cell bytes to the text line.

        Args:
            cells: Raw braille cell bytes (max 20 cells).

        Returns:
            True if ACK received, False otherwise.
        """
        return self.send_display_line(destination=0, cells=cells)

    def fill_rows(self, cells_per_row: int, rows: int, cell_value: int) -> None:
        """Fill multiple graphics rows with a repeated cell value."""
        row = bytes([cell_value]) * cells_per_row
        for idx in range(rows):
            destination = idx + 1
            self.send_display_line(destination, row)

    def clear_graphics(self) -> None:
        """Clear the 30x10 graphics area."""
        self.fill_rows(cells_per_row=30, rows=10, cell_value=0x00)

    def clear_text(self) -> None:
        """Clear the 20-cell text line."""
        self.send_text_bytes(bytes([0x00]) * 20)

    def clear_all(self) -> None:
        """Clear graphics and text."""
        self.clear_graphics()
        self.clear_text()

    def fill_graphics(self, cell_byte: int) -> None:
        """Fill the graphics area with a repeated cell byte."""
        self.fill_rows(cells_per_row=30, rows=10, cell_value=cell_byte)

    def send_text(
        self,
        text: str,
        use_number_sign: bool = True,
        use_nemeth: bool = False,
    ) -> None:
        """Encode text and send it to the text line.

        Args:
            text: Input text.
            use_number_sign: If True, insert number sign before digit runs.
            use_nemeth: If True, use lowered 6-dot (Nemeth-style) digit cells.
        """
        from .braille import encode_text_to_cells
        self.send_text_bytes(
            bytes(
                encode_text_to_cells(
                    text,
                    use_number_sign=use_number_sign,
                    use_nemeth=use_nemeth,
                )
            )
        )

    def send_graphics(
        self,
        text: str,
        row: int,
        col: int,
        use_number_sign: bool = True,
        use_nemeth: bool = False,
    ) -> None:
        """Render braille text into the graphics area at dot coordinates.

        Args:
            text: Input text.
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            use_number_sign: If True, insert number sign before digit runs.
            use_nemeth: If True, use lowered 6-dot (Nemeth-style) digit cells.
        """
        from .builder import DotPadBuilder
        builder = DotPadBuilder.empty()
        builder.render_text(
            text,
            row,
            col,
            use_number_sign=use_number_sign,
            use_nemeth=use_nemeth,
        )
        builder.send(self)

    def send_graphics_dots(self, dots: str | list[str], row: int, col: int) -> None:
        """Render dot-pattern cells into the graphics area at dot coordinates.

        Args:
            dots: Dot patterns (e.g., "145,24").
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
        """
        from .utils import dots_to_cells
        cells = bytes(dots_to_cells(dots))
        from .graphics import GraphicsBuffer
        buf = GraphicsBuffer.empty()
        buf.draw_braille_text(list(cells), start_row=row, start_col=col)
        for i, row_bytes in enumerate(buf.to_rows(), start=1):
            if any(b != 0 for b in row_bytes):
                self.send_display_line(i, row_bytes)

    def send_graphics_bytes(self, cells: bytes, row: int, col: int) -> None:
        """Render raw braille cell bytes into the graphics area at dot coordinates.

        Args:
            cells: Raw braille cell bytes.
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
        """
        from .graphics import GraphicsBuffer
        buf = GraphicsBuffer.empty()
        buf.draw_braille_text(list(cells), start_row=row, start_col=col)
        for i, row_bytes in enumerate(buf.to_rows(), start=1):
            if any(b != 0 for b in row_bytes):
                self.send_display_line(i, row_bytes)


    def draw_line(self, row: int, col: int, length: int) -> None:
        """Draw a horizontal line in dot coordinates."""
        from .builder import DotPadBuilder
        builder = DotPadBuilder.empty()
        builder.draw_line(row, col, length)
        builder.send(self)

    def draw_vline(self, row: int, col: int, length: int) -> None:
        """Draw a vertical line in dot coordinates."""
        from .builder import DotPadBuilder
        builder = DotPadBuilder.empty()
        builder.draw_vline(row, col, length)
        builder.send(self)

    def draw_rectangle(self, row1: int, col1: int, row2: int, col2: int) -> None:
        """Draw a rectangle using dot coordinates."""
        from .builder import DotPadBuilder
        builder = DotPadBuilder.empty()
        builder.draw_rectangle(row1, col1, row2, col2)
        builder.send(self)

    def draw_diag_line(self, row: int, col: int, length: int, direction: str = "ltr") -> None:
        """Draw a diagonal line in dot coordinates."""
        from .builder import DotPadBuilder
        builder = DotPadBuilder.empty()
        builder.draw_diag_line(row, col, length, direction)
        builder.send(self)
