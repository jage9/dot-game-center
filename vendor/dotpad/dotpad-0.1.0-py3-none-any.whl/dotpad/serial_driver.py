"""Transport-capable DotPad protocol driver (USB-first, BLE fallback)."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

import serial
from serial.tools import list_ports

try:
    from bleak import BleakClient, BleakScanner
except Exception:  # pragma: no cover - optional dependency
    BleakClient = None
    BleakScanner = None

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

DP_SYNC = b"\xaa\x55"
SERIAL_BAUD_RATE = 115200
DOTPAD_SERVICE_UUID = "49535343-fe7d-4ae5-8fa9-9fafd205e455"
DOTPAD_CHARACTERISTIC_UUID = "49535343-1e4d-4bd9-ba61-23c647249616"
DOTPAD_USB_IDS = {(0x0403, 0x6010), (0x0403, 0x6015)}


class PacketType(Enum):
    """Packet type identifiers used by the DotPad protocol."""

    # Display pipeline
    REQ_DISPLAY_LINE = b"\x02\x00"
    RSP_DISPLAY_LINE = b"\x02\x01"
    NTF_DISPLAY_LINE = b"\x02\x02"

    # Key notifications
    NTF_KEYS_SCROLL = b"\x03\x02"
    NTF_KEYS_PERKINS = b"\x03\x12"
    NTF_KEYS_ROUTING = b"\x03\x22"
    NTF_KEYS_FUNCTION = b"\x03\x32"

    # 3.0-style info requests/responses
    REQ_FW_VERSION = b"\x00\x00"
    RSP_FW_VERSION = b"\x00\x01"
    REQ_HW_VERSION = b"\x00\x10"
    RSP_HW_VERSION = b"\x00\x11"
    REQ_DEVICE_NAME = b"\x01\x00"
    RSP_DEVICE_NAME = b"\x01\x01"
    REQ_BOARD_INFO = b"\x01\x10"
    RSP_BOARD_INFO = b"\x01\x11"


class ResponseCode(Enum):
    """Response codes returned by display-line operations."""

    ACK = 0
    NAK = 1
    WAIT = 2
    CHECKSUM = 3

    @classmethod
    def from_code(cls, code: int) -> "ResponseCode":
        """Map a numeric response code to a ResponseCode enum.

        Args:
            code: Raw response code from the device.

        Returns:
            Matching ResponseCode; defaults to NAK if unknown.
        """
        for item in cls:
            if item.value == code:
                return item
        return ResponseCode.NAK


class KeyGroup(Enum):
    """Key notification group identifiers."""

    SCROLL = PacketType.NTF_KEYS_SCROLL.value[1]
    PERKINS = PacketType.NTF_KEYS_PERKINS.value[1]
    ROUTING = PacketType.NTF_KEYS_ROUTING.value[1]
    FUNCTION = PacketType.NTF_KEYS_FUNCTION.value[1]


@dataclass
class Packet:
    """Parsed protocol packet container."""

    raw: bytes
    length: int
    destination: int
    packet_type: Optional[PacketType]
    seq: int
    args: bytes
    checksum: int

    @staticmethod
    def calculate_checksum(data: bytes) -> int:
        """Compute the XOR checksum for a packet payload."""
        checksum = 0xA5
        for b in data:
            checksum ^= b
        return checksum

    @classmethod
    def make_packet(
        cls,
        packet_type: PacketType,
        args: bytes = b"",
        destination: int = 0,
        seq: int = 0,
    ) -> bytes:
        """Create a raw packet for transmission.

        Args:
            packet_type: Packet type enum.
            args: Payload bytes.
            destination: Destination line (0..10).
            seq: Sequence number.

        Returns:
            Raw packet bytes including sync and checksum.
        """
        destination_b = destination.to_bytes(1, "big")
        seq_b = seq.to_bytes(1, "big")
        length = len(destination_b + packet_type.value + seq_b + args) + 1
        length_b = length.to_bytes(2, "big")
        checksum = cls.calculate_checksum(destination_b + packet_type.value + seq_b + args)
        checksum_b = checksum.to_bytes(1, "big")
        return DP_SYNC + length_b + destination_b + packet_type.value + seq_b + args + checksum_b

    @classmethod
    def parse(cls, raw: bytes) -> "Packet":
        """Parse raw packet bytes into a Packet object."""
        length = int.from_bytes(raw[2:4], "big")
        destination = raw[4]
        packet_type = None
        try:
            packet_type = PacketType(raw[5:7])
        except ValueError:
            packet_type = None
        seq = raw[7]
        args = raw[8:-1]
        checksum = raw[-1]
        return cls(
            raw=raw,
            length=length,
            destination=destination,
            packet_type=packet_type,
            seq=seq,
            args=args,
            checksum=checksum,
        )


class _AsyncLoopRunner:
    """Run asyncio BLE operations from synchronous code."""

    def __init__(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def run(self, coro: Any, timeout: float = 10.0) -> Any:
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=timeout)

    def stop(self) -> None:
        if self._loop.is_closed():
            return
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=1.0)
        self._loop.close()


class _BlePort:
    """Minimal serial-like wrapper for DotPad BLE transport."""

    def __init__(
        self,
        timeout: float = 0.2,
        address: str | None = None,
        name_prefix: str = "DotPad",
        scan_timeout: float = 6.0,
    ) -> None:
        if BleakClient is None or BleakScanner is None:
            raise RuntimeError("BLE fallback requires optional dependency 'bleak'")

        self.timeout = timeout
        self.device_name = ""
        self.address = address
        self._name_prefix = name_prefix
        self._scan_timeout = scan_timeout
        self._runner = _AsyncLoopRunner()
        self._client: Any = None
        self._read_buffer = bytearray()
        self._read_cv = threading.Condition()
        self._is_open = False

        self._runner.run(self._connect_async(), timeout=max(scan_timeout + 6.0, 10.0))

    @property
    def in_waiting(self) -> int:
        with self._read_cv:
            return len(self._read_buffer)

    @property
    def is_open(self) -> bool:
        return self._is_open

    def _on_notify(self, _sender: Any, data: Any) -> None:
        chunk = bytes(data)
        if not chunk:
            return
        with self._read_cv:
            self._read_buffer.extend(chunk)
            self._read_cv.notify_all()

    def _on_disconnect(self, _client: Any) -> None:
        self._is_open = False
        with self._read_cv:
            self._read_cv.notify_all()

    async def _connect_async(self) -> None:
        target = None
        if self.address:
            try:
                target = await BleakScanner.find_device_by_address(self.address, timeout=self._scan_timeout)
            except Exception:
                target = None
        if target is None:
            devices = await BleakScanner.discover(timeout=self._scan_timeout)
            for dev in devices:
                name = getattr(dev, "name", "") or ""
                if name.startswith(self._name_prefix):
                    target = dev
                    break
        if target is None:
            raise RuntimeError("No DotPad BLE device found")

        self.address = getattr(target, "address", None)
        self.device_name = getattr(target, "name", "") or "DotPad BLE"

        client = BleakClient(target, disconnected_callback=self._on_disconnect)
        await client.connect()
        await client.start_notify(DOTPAD_CHARACTERISTIC_UUID, self._on_notify)
        self._client = client
        self._is_open = True

    async def _write_async(self, data: bytes) -> None:
        if not self._client:
            raise RuntimeError("BLE client is not connected")
        mtu = 20
        for idx in range(0, len(data), mtu):
            chunk = data[idx : idx + mtu]
            await self._client.write_gatt_char(DOTPAD_CHARACTERISTIC_UUID, chunk, response=True)

    def write(self, data: bytes) -> int:
        if not self._is_open:
            raise RuntimeError("BLE DotPad is disconnected")
        self._runner.run(self._write_async(data), timeout=10.0)
        return len(data)

    def read(self, n: int) -> bytes:
        return self.read_timeout(n, self.timeout)

    def read_timeout(self, n: int, timeout: float) -> bytes:
        if n <= 0:
            return b""
        end = time.time() + max(0.0, timeout)
        with self._read_cv:
            while self._is_open and len(self._read_buffer) == 0:
                remaining = end - time.time()
                if remaining <= 0:
                    break
                self._read_cv.wait(timeout=remaining)
            if len(self._read_buffer) == 0:
                return b""
            out = bytes(self._read_buffer[:n])
            del self._read_buffer[:n]
            return out

    async def _close_async(self) -> None:
        if self._client is None:
            return
        try:
            await self._client.stop_notify(DOTPAD_CHARACTERISTIC_UUID)
        except Exception:
            pass
        try:
            await self._client.disconnect()
        except Exception:
            pass

    def close(self) -> None:
        self._is_open = False
        try:
            self._runner.run(self._close_async(), timeout=5.0)
        except Exception:
            pass
        with self._read_cv:
            self._read_buffer.clear()
            self._read_cv.notify_all()
        self._runner.stop()


class DotPad:
    """DotPad driver with USB serial first and optional BLE fallback."""

    def __init__(
        self,
        port: str | None = None,
        timeout: float = 0.2,
        transport: str = "auto",
        ble_address: str | None = None,
        ble_name_prefix: str = "DotPad",
        ble_scan_timeout: float = 6.0,
    ) -> None:
        """Create a DotPad instance.

        Args:
            port: Serial port name (for USB), e.g. "COM5".
            timeout: Read timeout in seconds.
            transport: One of "auto", "usb", or "ble".
            ble_address: Optional BLE address for direct reconnect.
            ble_name_prefix: BLE scan name prefix in fallback mode.
            ble_scan_timeout: BLE scan timeout in seconds.

        Raises:
            RuntimeError: If no usable USB/BLE DotPad connection can be opened.
        """
        self.timeout = timeout
        self.connection_type = ""
        self.port = port
        self.address = ble_address
        self.device_name = ""

        # Keep naming compatible with existing callers (e.g., dgc) that inspect _ser.
        self._ser: Any = None

        # Cached display capability defaults (DotPad 320 layout).
        self.support_text = True
        self.support_graphics = True
        self.number_cell_rows = 10
        self.number_cell_columns = 30
        self.number_braille_cell_rows = 1
        self.number_braille_cell_columns = 20

        self._packet_buffer: list[Packet] = []

        desired = (transport or "auto").strip().lower()
        if desired not in {"auto", "usb", "ble"}:
            raise ValueError("transport must be one of: auto, usb, ble")

        errors: list[str] = []

        if port is not None or desired in {"auto", "usb"}:
            try:
                usb_port = port if port is not None else self.detect_port()
                if usb_port:
                    self._ser = serial.Serial(usb_port, SERIAL_BAUD_RATE, timeout=timeout)
                    self.connection_type = "usb"
                    self.port = usb_port
            except Exception as exc:
                errors.append(f"USB: {exc}")

        if self._ser is None and desired in {"auto", "ble"}:
            try:
                ble_port = _BlePort(
                    timeout=timeout,
                    address=ble_address,
                    name_prefix=ble_name_prefix,
                    scan_timeout=ble_scan_timeout,
                )
                self._ser = ble_port
                self.connection_type = "ble"
                self.address = ble_port.address
                self.device_name = ble_port.device_name
                self.port = f"BLE:{self.address or 'unknown'}"
            except Exception as exc:
                errors.append(f"BLE: {exc}")

        if self._ser is None:
            raise RuntimeError(
                "No DotPad connection available (USB first, BLE fallback). "
                + (" | ".join(errors) if errors else "")
            )

        # Best effort: read board info to fill modern capability fields.
        try:
            self.refresh_capabilities(timeout=0.8)
        except Exception:
            pass

    @classmethod
    def scan_usb_ports(cls) -> list[dict[str, Any]]:
        """Scan USB serial ports likely to be DotPad devices.

        Returns:
            List of dictionaries with `device`, `description`, `vid`, and `pid`.
        """
        matches: list[dict[str, Any]] = []
        for p in list_ports.comports():
            vid_pid_match = (p.vid, p.pid) in DOTPAD_USB_IDS
            text_match = "dotpad" in (p.description or "").lower()
            if vid_pid_match or text_match:
                matches.append(
                    {
                        "device": p.device,
                        "description": p.description,
                        "vid": p.vid,
                        "pid": p.pid,
                    }
                )
        return matches

    @classmethod
    def scan_ble_devices(cls, timeout: float = 6.0, name_prefix: str = "DotPad") -> list[dict[str, str]]:
        """Scan BLE devices matching DotPad naming.

        Args:
            timeout: Scan timeout in seconds.
            name_prefix: Device name prefix to match.

        Returns:
            List of dictionaries with `name` and `address`.
        """
        if BleakScanner is None:
            return []

        async def _scan() -> list[dict[str, str]]:
            items: list[dict[str, str]] = []
            for dev in await BleakScanner.discover(timeout=timeout):
                name = getattr(dev, "name", "") or ""
                if name.startswith(name_prefix):
                    items.append(
                        {
                            "name": name,
                            "address": str(getattr(dev, "address", "")),
                        }
                    )
            return items

        try:
            return asyncio.run(_scan())
        except RuntimeError:
            runner = _AsyncLoopRunner()
            try:
                return runner.run(_scan(), timeout=max(timeout + 4.0, 8.0))
            finally:
                runner.stop()

    @classmethod
    def detect_port(cls) -> str | None:
        """Detect the first likely DotPad USB serial port.

        Returns:
            COM port string or None if no matching USB port is found.
        """
        for p in list_ports.comports():
            if (p.vid, p.pid) in DOTPAD_USB_IDS:
                return p.device
        return None

    def connection_info(self) -> dict[str, Any]:
        """Return current connection metadata.

        Returns:
            Dictionary with transport, endpoint details, and known capabilities.
        """
        return {
            "transport": self.connection_type,
            "port": self.port,
            "address": self.address,
            "device_name": self.device_name,
            "supports_text": self.support_text,
            "supports_graphics": self.support_graphics,
            "number_cell_rows": self.number_cell_rows,
            "number_cell_columns": self.number_cell_columns,
            "number_braille_cell_rows": self.number_braille_cell_rows,
            "number_braille_cell_columns": self.number_braille_cell_columns,
        }

    def builder(self):
        """Create a new DotPadBuilder for buffered graphics."""
        from .builder import DotPadBuilder

        return DotPadBuilder.empty()

    def close(self) -> None:
        """Close the underlying transport."""
        if self._ser is None:
            return
        is_open = getattr(self._ser, "is_open", True)
        if is_open:
            self._ser.close()

    def _read_port(self, n: int, timeout: float | None = None) -> bytes:
        """Read bytes from the active transport with an optional timeout."""
        if timeout is not None and hasattr(self._ser, "read_timeout"):
            return self._ser.read_timeout(n, timeout)
        if timeout is not None and hasattr(self._ser, "timeout"):
            old_timeout = self._ser.timeout
            try:
                self._ser.timeout = timeout
                return self._ser.read(n)
            finally:
                self._ser.timeout = old_timeout
        return self._ser.read(n)

    def _read_exact(self, n: int, timeout: float | None = None) -> bytes:
        """Read exactly n bytes from the active transport (best effort)."""
        if n <= 0:
            return b""
        data = bytearray()
        deadline = time.time() + timeout if timeout is not None else None
        while len(data) < n:
            if deadline is not None:
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                chunk = self._read_port(n - len(data), timeout=min(remaining, 0.1))
            else:
                chunk = self._read_port(n - len(data))
            if not chunk:
                if deadline is None:
                    break
                continue
            data.extend(chunk)
        return bytes(data)

    def read_packet(self, timeout: float = 0.5) -> Optional[Packet]:
        """Read a single protocol packet from the device, if available.

        Args:
            timeout: Max time in seconds to wait for one complete packet.

        Returns:
            Parsed Packet, or None on timeout/no packet.
        """
        if self._packet_buffer:
            return self._packet_buffer.pop(0)

        deadline = time.time() + timeout
        while time.time() < deadline:
            remaining = max(0.0, deadline - time.time())
            b = self._read_port(1, timeout=min(remaining, 0.05))
            if not b:
                continue
            if b != DP_SYNC[:1]:
                continue

            remaining = max(0.0, deadline - time.time())
            b2 = self._read_port(1, timeout=min(remaining, 0.05))
            if b2 != DP_SYNC[1:2]:
                continue

            remaining = max(0.0, deadline - time.time())
            length_b = self._read_exact(2, timeout=remaining)
            if len(length_b) < 2:
                continue

            length = int.from_bytes(length_b, "big")
            remaining = max(0.0, deadline - time.time())
            payload = self._read_exact(length, timeout=remaining)
            if len(payload) < length:
                continue

            raw = DP_SYNC + length_b + payload
            return Packet.parse(raw)
        return None

    @staticmethod
    def _decode_keys(args: bytes) -> list[int]:
        """Decode packed key bits into a list of key indices."""
        keys_pressed_bitstring = b""
        for byte in args:
            bit_string = format(byte, "08b").encode()
            reversed_bit_string = bit_string[::-1]
            keys_pressed_bitstring = reversed_bit_string + keys_pressed_bitstring
        keys_pressed = int(keys_pressed_bitstring, 2) if keys_pressed_bitstring else 0
        pressed = []
        for i in range(len(args) * 8):
            if (keys_pressed >> i) & 1:
                pressed.append(i)
        return pressed

    @staticmethod
    def _map_key_names(group_num: int, keys: list[int]) -> list[str]:
        """Map key indices to friendly names for known groups."""
        names: list[str] = []
        if group_num == KeyGroup.FUNCTION.value:
            for key in keys:
                # 1.0 style mapping
                if key < 4:
                    names.append(f"f{key + 1}")
        elif group_num == KeyGroup.PERKINS.value:
            for key in keys:
                # 1.0 style mapping
                if key == 13:
                    names.append("panLeft")
                elif key == 14:
                    names.append("panRight")
        return names

    def listen_keys(self, callback, timeout: float = 0.5) -> None:
        """Listen for key notifications and call callback(names).

        Args:
            callback: Function called with a list of key names.
            timeout: Read timeout used while listening.
        """
        while True:
            pkt = self.read_packet(timeout=timeout)
            if not pkt or pkt.packet_type is None:
                continue
            if pkt.packet_type in (
                PacketType.NTF_KEYS_SCROLL,
                PacketType.NTF_KEYS_PERKINS,
                PacketType.NTF_KEYS_ROUTING,
                PacketType.NTF_KEYS_FUNCTION,
            ):
                group_num = pkt.packet_type.value[1]
                keys = self._decode_keys(pkt.args)
                if not keys:
                    continue
                names = self._map_key_names(group_num, keys)
                try:
                    callback(names)
                except Exception:
                    logger.exception("Key callback raised an exception")

    def listen_chords(self, callback, timeout: float = 0.5, debounce: float = 0.05) -> None:
        """Listen for chorded keys and call callback(names) on release.

        Args:
            callback: Function called with the chord key list.
            timeout: Read timeout used while listening.
            debounce: Window to collect late packets on release.
        """
        current_groups: dict[int, set[int]] = {}
        last_names: list[str] = []
        while True:
            pkt = self.read_packet(timeout=timeout)
            if not pkt or pkt.packet_type is None:
                continue
            if pkt.packet_type not in (
                PacketType.NTF_KEYS_SCROLL,
                PacketType.NTF_KEYS_PERKINS,
                PacketType.NTF_KEYS_ROUTING,
                PacketType.NTF_KEYS_FUNCTION,
            ):
                continue
            group_num = pkt.packet_type.value[1]
            keys = self._decode_keys(pkt.args)
            if keys:
                current_groups[group_num] = set(keys)
                names: list[str] = []
                for grp, grp_keys in current_groups.items():
                    names.extend(self._map_key_names(grp, sorted(grp_keys)))
                last_names = names
                continue

            if group_num in current_groups:
                current_groups.pop(group_num)
            if not current_groups and last_names:
                deadline = time.time() + debounce
                while time.time() < deadline:
                    pkt2 = self.read_packet(timeout=0.01)
                    if not pkt2 or pkt2.packet_type is None:
                        continue
                    if pkt2.packet_type not in (
                        PacketType.NTF_KEYS_SCROLL,
                        PacketType.NTF_KEYS_PERKINS,
                        PacketType.NTF_KEYS_ROUTING,
                        PacketType.NTF_KEYS_FUNCTION,
                    ):
                        continue
                    grp2 = pkt2.packet_type.value[1]
                    keys2 = self._decode_keys(pkt2.args)
                    if keys2:
                        current_groups[grp2] = set(keys2)
                        names: list[str] = []
                        for grp, grp_keys in current_groups.items():
                            names.extend(self._map_key_names(grp, sorted(grp_keys)))
                        last_names = names
                        break
                if not current_groups:
                    try:
                        callback(last_names)
                    except Exception:
                        logger.exception("Chord callback raised an exception")
                    last_names = []

    def send_display_line(self, destination: int, cells: bytes) -> bool:
        """Send a single row to a destination line with retries.

        Args:
            destination: 1..10 for graphics, 0 for text line.
            cells: Row bytes (30 for graphics, up to 20 for text).

        Returns:
            True if ACK received, False otherwise.
        """
        args = bytes([0]) + cells
        packet = Packet.make_packet(PacketType.REQ_DISPLAY_LINE, args=args, destination=destination, seq=0)

        for attempt in range(2):
            self._ser.write(packet)
            # Small delay to give device time to process
            time.sleep(0.01)

            deadline = time.time() + 0.8
            while time.time() < deadline:
                pkt = self.read_packet(timeout=max(0.01, deadline - time.time()))
                if not pkt or pkt.packet_type is None:
                    continue
                if pkt.packet_type == PacketType.NTF_DISPLAY_LINE:
                    return True
                if pkt.packet_type == PacketType.RSP_DISPLAY_LINE and pkt.args:
                    code = ResponseCode.from_code(pkt.args[0])
                    if code == ResponseCode.ACK:
                        return True
                    if code == ResponseCode.WAIT:
                        time.sleep(0.05)
                        break # retry write
                # Unsolicited packet (e.g. key press) - buffer it for the key listener
                self._packet_buffer.append(pkt)
            
            # If we timed out or got a NAK/WAIT, we'll loop and retry once
            if attempt == 0:
                time.sleep(0.02)
        
        return False

    def send_graphic_frame(self, rows: list[bytes | bytearray | list[int] | tuple[int, ...]]) -> bool:
        """Send a full graphics frame (all 10 rows) in one protocol packet.

        Args:
            rows: Sequence of row-like objects containing cell bytes.

        Returns:
            True if ACK received, False otherwise.
        """
        # Build exactly 300 bytes of payload (10 rows x 30 cells).
        full_payload = []
        for row_idx in range(self.number_cell_rows):
            src = rows[row_idx] if row_idx < len(rows) else ()
            row_list = list(src)
            padded = (row_list + [0x00] * self.number_cell_columns)[: self.number_cell_columns]
            full_payload.extend(padded)
        
        # Arguments: start cell index (0), then the 300 bytes.
        # destination=1 for graphics.
        args = bytes([0]) + bytes(full_payload)
        packet = Packet.make_packet(PacketType.REQ_DISPLAY_LINE, args=args, destination=1, seq=0)

        for attempt in range(2):
            self._ser.write(packet)
            time.sleep(0.02) # Extra processing time for large packet

            deadline = time.time() + 1.5
            while time.time() < deadline:
                pkt = self.read_packet(timeout=max(0.01, deadline - time.time()))
                if not pkt or pkt.packet_type is None:
                    continue
                if pkt.packet_type == PacketType.NTF_DISPLAY_LINE:
                    return True
                if pkt.packet_type == PacketType.RSP_DISPLAY_LINE and pkt.args:
                    code = ResponseCode.from_code(pkt.args[0])
                    if code == ResponseCode.ACK:
                        return True
                    if code == ResponseCode.WAIT:
                        time.sleep(0.1)
                        break
                self._packet_buffer.append(pkt)
            if attempt == 0:
                time.sleep(0.05)
        
        return False

    def send_graphic_frame_with_line0(
        self,
        rows: list[bytes | bytearray | list[int] | tuple[int, ...]],
        text_cells: bytes | bytearray | list[int] | tuple[int, ...],
    ) -> bool:
        """Send full graphics and text-line payload in one wrapper operation.

        Args:
            rows: Sequence of graphics rows.
            text_cells: Text-line braille cells for destination line 0.

        Returns:
            True if all sends ACK; False if any send fails.
        """
        ok = self.send_graphic_frame(rows)
        text_list = list(text_cells)
        padded = (text_list + [0x00] * self.number_braille_cell_columns)[: self.number_braille_cell_columns]
        return self.send_display_line(0, bytes(padded)) and ok

    def _request_info_packet(
        self,
        request_packet_type: PacketType,
        response_packet_type: PacketType,
        timeout: float,
    ) -> Optional[Packet]:
        """Send one info request and wait for its matching response packet."""
        packet = Packet.make_packet(request_packet_type, args=b"", destination=0, seq=0)
        self._ser.write(packet)
        deadline = time.time() + timeout
        while time.time() < deadline:
            pkt = self.read_packet(timeout=max(0.01, deadline - time.time()))
            if not pkt or pkt.packet_type is None:
                continue
            if pkt.packet_type == response_packet_type:
                return pkt
        return None

    @staticmethod
    def _decode_ascii_payload(args: bytes) -> str:
        """Decode ASCII payload from response bytes."""
        return args.split(b"\x00", 1)[0].decode("ascii", errors="ignore")

    @staticmethod
    def _parse_board_info(args: bytes) -> dict[str, Any]:
        """Parse board info payload into capability fields."""
        info: dict[str, Any] = {
            "supports_graphics": True,
            "supports_text": True,
            "number_braille_cell_rows": 1,
            "number_braille_cell_columns": 20,
            "number_cell_rows": 10,
            "number_cell_columns": 30,
            "raw": args,
        }
        if len(args) < 10:
            return info

        flags_high_nibble = (args[0] >> 4) & 0x0F
        info["supports_graphics"] = bool(flags_high_nibble & 0x08)
        info["supports_text"] = bool(flags_high_nibble & 0x04)

        if len(args) >= 6:
            info["number_braille_cell_rows"] = args[4]
            info["number_braille_cell_columns"] = args[5]
        if len(args) >= 10:
            info["number_cell_rows"] = args[8]
            info["number_cell_columns"] = args[9]

        return info

    def request_device_info(self, info_type: str, timeout: float = 0.8) -> Any:
        """Request modern device metadata (3.0 style command set).

        Args:
            info_type: One of `device_name`, `firmware_version`, `hardware_version`, or `board_info`.
            timeout: Max wait time for response.

        Returns:
            Parsed response value (string or dict), or None if no response.
        """
        key = info_type.strip().lower().replace(" ", "_")
        if key in {"name", "device", "device_name"}:
            pkt = self._request_info_packet(PacketType.REQ_DEVICE_NAME, PacketType.RSP_DEVICE_NAME, timeout)
            return self._decode_ascii_payload(pkt.args) if pkt else None
        if key in {"fw", "firmware", "firmware_version"}:
            pkt = self._request_info_packet(PacketType.REQ_FW_VERSION, PacketType.RSP_FW_VERSION, timeout)
            return self._decode_ascii_payload(pkt.args) if pkt else None
        if key in {"hw", "hardware", "hardware_version"}:
            pkt = self._request_info_packet(PacketType.REQ_HW_VERSION, PacketType.RSP_HW_VERSION, timeout)
            return pkt.args.hex() if pkt else None
        if key in {"board", "board_info", "display_info"}:
            pkt = self._request_info_packet(PacketType.REQ_BOARD_INFO, PacketType.RSP_BOARD_INFO, timeout)
            return self._parse_board_info(pkt.args) if pkt else None
        raise ValueError(f"Unsupported info_type: {info_type}")

    def get_display_info(self, timeout: float = 0.8) -> dict[str, Any]:
        """Get display capabilities from board info.

        Args:
            timeout: Max wait for board-info response.

        Returns:
            Dictionary with display capability fields.
        """
        info = self.request_device_info("board_info", timeout=timeout)
        if isinstance(info, dict):
            return info
        return {
            "supports_graphics": self.support_graphics,
            "supports_text": self.support_text,
            "number_braille_cell_rows": self.number_braille_cell_rows,
            "number_braille_cell_columns": self.number_braille_cell_columns,
            "number_cell_rows": self.number_cell_rows,
            "number_cell_columns": self.number_cell_columns,
        }

    def refresh_capabilities(self, timeout: float = 0.8) -> dict[str, Any]:
        """Refresh cached capability fields from the device.

        Args:
            timeout: Max wait for board-info response.

        Returns:
            Parsed capability dictionary.
        """
        info = self.get_display_info(timeout=timeout)
        self.support_graphics = bool(info.get("supports_graphics", self.support_graphics))
        self.support_text = bool(info.get("supports_text", self.support_text))
        self.number_braille_cell_rows = int(
            info.get("number_braille_cell_rows", self.number_braille_cell_rows)
        )
        self.number_braille_cell_columns = int(
            info.get("number_braille_cell_columns", self.number_braille_cell_columns)
        )
        self.number_cell_rows = int(info.get("number_cell_rows", self.number_cell_rows))
        self.number_cell_columns = int(info.get("number_cell_columns", self.number_cell_columns))
        return info

    def send_text_dots(self, dots: str | list[str]) -> bool:
        """Send dot-pattern cells to the text line.

        Args:
            dots: Dot patterns (e.g., "3456 1 12" or ["3456", "1", "12"]).

        Returns:
            True if ACK received, False otherwise.
        """
        from .utils import dots_to_cells

        cells = bytes(dots_to_cells(dots))
        return self.send_display_line(destination=0, cells=cells)

    def send_text_bytes(self, cells: bytes) -> bool:
        """Send raw braille cell bytes to the text line.

        Args:
            cells: Raw braille cell bytes (max 20 cells).

        Returns:
            True if ACK received, False otherwise.
        """
        return self.send_display_line(destination=0, cells=cells)

    def fill_rows(self, cells_per_row: int, rows: int, cell_value: int) -> bool:
        """Fill multiple graphics rows with a repeated cell value.

        Args:
            cells_per_row: Cells per row (e.g. 30).
            rows: Number of rows (e.g. 10).
            cell_value: Byte value to write.

        Returns:
            True if successful, False otherwise.
        """
        if rows == self.number_cell_rows and cells_per_row == self.number_cell_columns:
            # Optimize full graphics fill with a single frame packet.
            row_data = bytes([cell_value]) * cells_per_row
            return self.send_graphic_frame([row_data] * rows)

        ok = True
        for idx in range(rows):
            destination = idx + 1
            if not self.send_display_line(destination, bytes([cell_value]) * cells_per_row):
                ok = False
        return ok

    def clear_graphics(self) -> None:
        """Clear the graphics area."""
        self.fill_rows(cells_per_row=self.number_cell_columns, rows=self.number_cell_rows, cell_value=0x00)

    def clear_text(self) -> None:
        """Clear the braille text line."""
        self.send_text_bytes(bytes([0x00]) * self.number_braille_cell_columns)

    def clear_all(self) -> None:
        """Clear graphics and text areas."""
        self.clear_graphics()
        self.clear_text()

    def fill_graphics(self, cell_byte: int) -> None:
        """Fill the graphics area with a repeated cell byte."""
        self.fill_rows(
            cells_per_row=self.number_cell_columns,
            rows=self.number_cell_rows,
            cell_value=cell_byte,
        )

    def send_text(
        self,
        text: str,
        use_number_sign: bool = True,
        use_nemeth: bool = False,
        use_capital_sign: bool = True,
    ) -> None:
        """Encode text and send it to the text line.

        Args:
            text: Input text.
            use_number_sign: If True, insert number sign before digit runs.
            use_nemeth: If True, use lowered 6-dot (Nemeth-style) digit cells.
            use_capital_sign: If True, prepend dot-6 before uppercase letters.
        """
        from .braille import encode_text_to_cells

        self.send_text_bytes(
            bytes(
                encode_text_to_cells(
                    text,
                    use_number_sign=use_number_sign,
                    use_nemeth=use_nemeth,
                    use_capital_sign=use_capital_sign,
                )
            )
        )

    def send_graphics(
        self,
        text: str,
        row: int,
        col: int,
        use_number_sign: bool = True,
        use_nemeth: bool = False,
        direction: str = "right",
        use_capital_sign: bool = True,
    ) -> None:
        """Render braille text into the graphics area at dot coordinates.

        Args:
            text: Input text.
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            use_number_sign: If True, insert number sign before digit runs.
            use_nemeth: If True, use lowered 6-dot (Nemeth-style) digit cells.
            direction: Text flow direction: right (default), left, up, or down.
                Non-right directions rotate each cell while keeping dot-1
                anchored at the provided row/col.
            use_capital_sign: If True, prepend dot-6 before uppercase letters.
        """
        from .builder import DotPadBuilder

        builder = DotPadBuilder.empty()
        builder.render_text(
            text,
            row,
            col,
            use_number_sign=use_number_sign,
            use_nemeth=use_nemeth,
            direction=direction,
            use_capital_sign=use_capital_sign,
        )
        builder.send(self)

    def send_graphics_dots(
        self,
        dots: str | list[str],
        row: int,
        col: int,
        direction: str = "right",
    ) -> None:
        """Render dot-pattern cells into the graphics area at dot coordinates.

        Args:
            dots: Dot patterns (e.g., "145,24").
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            direction: Text flow direction: right (default), left, up, or down.
                Non-right directions rotate each cell while keeping dot-1
                anchored at the provided row/col.
        """
        from .graphics import GraphicsBuffer
        from .utils import dots_to_cells

        cells = bytes(dots_to_cells(dots))
        buf = GraphicsBuffer.empty()
        buf.draw_braille_text(list(cells), start_row=row, start_col=col, direction=direction)
        for i, row_bytes in enumerate(buf.to_rows(), start=1):
            if any(b != 0 for b in row_bytes):
                self.send_display_line(i, row_bytes)

    def send_graphics_bytes(
        self,
        cells: bytes,
        row: int,
        col: int,
        direction: str = "right",
    ) -> None:
        """Render raw braille cell bytes into graphics at dot coordinates.

        Args:
            cells: Raw braille cell bytes.
            row: Starting dot row (1-based).
            col: Starting dot column (1-based).
            direction: Text flow direction: right (default), left, up, or down.
                Non-right directions rotate each cell while keeping dot-1
                anchored at the provided row/col.
        """
        from .graphics import GraphicsBuffer

        buf = GraphicsBuffer.empty()
        buf.draw_braille_text(list(cells), start_row=row, start_col=col, direction=direction)
        for i, row_bytes in enumerate(buf.to_rows(), start=1):
            if any(b != 0 for b in row_bytes):
                self.send_display_line(i, row_bytes)

    def draw_line(self, row: int, col: int, length: int) -> None:
        """Draw a horizontal line in dot coordinates."""
        from .builder import DotPadBuilder

        builder = DotPadBuilder.empty()
        builder.draw_line(row, col, length)
        builder.send(self)

    def draw_vline(self, row: int, col: int, length: int) -> None:
        """Draw a vertical line in dot coordinates."""
        from .builder import DotPadBuilder

        builder = DotPadBuilder.empty()
        builder.draw_vline(row, col, length)
        builder.send(self)

    def draw_rectangle(self, row1: int, col1: int, row2: int, col2: int) -> None:
        """Draw a rectangle using dot coordinates."""
        from .builder import DotPadBuilder

        builder = DotPadBuilder.empty()
        builder.draw_rectangle(row1, col1, row2, col2)
        builder.send(self)

    def draw_diag_line(self, row: int, col: int, length: int, direction: str = "ltr") -> None:
        """Draw a diagonal line in dot coordinates."""
        from .builder import DotPadBuilder

        builder = DotPadBuilder.empty()
        builder.draw_diag_line(row, col, length, direction)
        builder.send(self)
