import argparse
import sys
from pathlib import Path

import dotpad as dp

DTM_SIGNATURE = b"_dtm_"
DTM_HEADER_LEN = 30


def parse_dtm(path: Path) -> dict:
    raw = path.read_bytes()
    if len(raw) < DTM_HEADER_LEN:
        raise ValueError(f"DTM file too small: {len(raw)} bytes")
    if not raw.startswith(DTM_SIGNATURE):
        raise ValueError("Missing _dtm_ signature")

    width = raw[5]
    height = raw[6]
    header = raw[:DTM_HEADER_LEN]
    data = raw[DTM_HEADER_LEN:]
    return {
        "path": path,
        "size": len(raw),
        "signature": raw[:5],
        "width": width,
        "height": height,
        "header": header,
        "data": data,
    }


def print_info(info: dict) -> None:
    data = info["data"]
    nonzero = sum(1 for b in data if b)
    print(f"File: {info['path']}")
    print(f"Size: {info['size']} bytes")
    print(f"Signature: {info['signature']!r}")
    print(f"Header bytes (hex): {info['header'].hex()}")
    print(f"Header width/height bytes: {info['width']} x {info['height']}")
    print(f"Payload length: {len(data)} bytes")
    print(f"Non-zero cells: {nonzero}")


def send_to_dot(data: bytes, cols: int, rows: int, port: str | None) -> None:
    expected = cols * rows
    if len(data) != expected:
        raise ValueError(f"Payload length {len(data)} != cols*rows {expected}")
    pad = dp.DotPad(port=port)
    pad.clear_graphics()
    for row_idx in range(rows):
        start = row_idx * cols
        row = data[start:start + cols]
        pad.send_display_line(row_idx + 1, row)
    pad.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="DTM file inspector")
    parser.add_argument("path", help="Path to .dtm file")
    parser.add_argument("--send", action="store_true", help="Display DTM on DotPad")
    parser.add_argument("--port", default=None, help="COM port, e.g., COM5 (auto-detect if omitted)")
    parser.add_argument("--cols", type=int, default=30, help="Columns for display (default 30)")
    parser.add_argument("--rows", type=int, default=10, help="Rows for display (default 10)")
    parser.add_argument(
        "--use-header",
        action="store_true",
        help="Use header width/height for cols/rows",
    )
    if len(sys.argv) == 1:
        parser.print_help()
        raise SystemExit(1)
    args = parser.parse_args()

    info = parse_dtm(Path(args.path))
    print_info(info)

    if args.send:
        cols = args.cols
        rows = args.rows
        if args.use_header:
            cols = info["width"]
            rows = info["height"]
        send_to_dot(info["data"], cols, rows, args.port)


if __name__ == "__main__":
    main()
